import { useState } from "react";

const Header = () => {
  return (
    <div className="text-center">
      <h1>App with React + Django</h1>
    </div>
  );
};
export default Header;
